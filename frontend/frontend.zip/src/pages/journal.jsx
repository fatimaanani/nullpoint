import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../styles/journal.css";
import TopBar from "../components/topBar";

function Journal() {
  const [entry, setEntry] = useState("");
  const [selectedMoods, setSelectedMoods] = useState([]);
  const [customTags, setCustomTags] = useState([]);
  const [isAddingTag, setIsAddingTag] = useState(false);
  const [newTagText, setNewTagText] = useState("");
  const [feedbackMessage, setFeedbackMessage] = useState("");

  const moods = ["calm", "tired", "grateful", "overwhelmed", "peaceful", "anxious"];

  const toggleMood = (tag) => {
    if (selectedMoods.includes(tag)) {
      setSelectedMoods(selectedMoods.filter((t) => t !== tag));
    } else {
      setSelectedMoods([...selectedMoods, tag]);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!entry.trim()) {
      setFeedbackMessage("You submitted an empty entry (╯°□°）╯︵ ┻━┻");
      setTimeout(() => setFeedbackMessage(""), 2000);
      return;
    }

    setFeedbackMessage("Entry submitted successfully (๑˃̵ᴗ˂̵)و");
    setTimeout(() => setFeedbackMessage(""), 2000);

    setEntry("");
    setSelectedMoods([]);
  };

  const handleCreateTag = () => {
    const clean = newTagText.trim().toLowerCase();
    if (clean && !customTags.includes(clean)) {
      setCustomTags([...customTags, clean]);
    }
    setNewTagText("");
    setIsAddingTag(false);
  };

  return (
    <div className="journalwrite-container">
      <TopBar title="Journal" />

      <div className="paper-sheet">
        <p className="dear-diary">Dear Diary,</p>

        <textarea
          className="diary-textarea"
          value={entry}
          onChange={(e) => setEntry(e.target.value)}
          placeholder="write your thoughts here..."
        ></textarea>

        <button className="submit-entry-btn" onClick={handleSubmit}>
          Submit Entry
        </button>

        {feedbackMessage && (
          <div className="journal-feedback">{feedbackMessage}</div>
        )}
      </div>

      <div className="tags-under-paper">
        {moods.map((tag) => (
          <span
            key={tag}
            className={`tag-chip ${selectedMoods.includes(tag) ? "selected" : ""}`}
            onClick={() => toggleMood(tag)}
          >
            {tag}
          </span>
        ))}

        {customTags.map((tag, i) => (
          <span
            key={i}
            className={`tag-chip ${selectedMoods.includes(tag) ? "selected" : ""}`}
            onClick={() => toggleMood(tag)}
          >
            {tag}
          </span>
        ))}

        {isAddingTag && (
          <div className="new-tag-box">
            <input
              type="text"
              className="new-tag-input"
              placeholder="new tag..."
              value={newTagText}
              onChange={(e) => setNewTagText(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleCreateTag()}
            />
            <button className="new-tag-save" onClick={handleCreateTag}>
              ✔
            </button>
          </div>
        )}

        {!isAddingTag && (
          <button className="add-tag-chip" onClick={() => setIsAddingTag(true)}>
            + Add Tag
          </button>
        )}
      </div>

      <div className="below-paper">
        <p className="quote">“Progress is quiet work.”</p>

        <Link className="log-button" to="/journal-log">
          View journal log →
        </Link>
      </div>
    </div>
  );
}

export default Journal;
