import React, { useState } from "react";
import { Venus, Mars, Circle, ChevronDown, ChevronUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import "../styles/profile.css";

function Profile() {
  const [gender, setGender] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [genderLocked, setGenderLocked] = useState(false);
  const [about, setAbout] = useState("");
  const [isEditing, setIsEditing] = useState(false);

  const navigate = useNavigate();

  const handleGenderSelect = (value) => {
    if (genderLocked) return;
    setGender(value);
    setIsOpen(false);
    setGenderLocked(true);
  };

  const getIcon = () => {
    // Logic updated to match the exact strings being sent below
    if (gender === "Female") return <Venus className="gender-symbol female" />;
    if (gender === "Male") return <Mars className="gender-symbol male" />;
    if (gender === "Anonymous") return <Circle className="gender-symbol neutral" />;
    return <Circle className="gender-symbol placeholder" />;
  };

  const getProfileDisplayName = () => {
    return localStorage.getItem("stored_username");
  };

  const getProfileFullName = () => {
    return localStorage.getItem("stored_fullName");
  };

  const getProfileEmail = () => {
    return localStorage.getItem("stored_email");
  };

  return (
    <div className="profile-container">
      <div className="profile-layout">
        <div className="profile-left">
          <div className="profile-icon">
            {getIcon()}
          </div>
        </div>

        <div className="profile-right">
          <div className="profile-header">
            <h2 className="profile-name">{getProfileDisplayName()}</h2>
            <div className="gender-dropdown-container">
              <button
                className={`gender-toggle ${genderLocked ? "locked" : ""}`}
                onClick={() => !genderLocked && setIsOpen(!isOpen)}
              >
                {/* Updated display logic to handle the "Anonymous" text better */}
                {gender ? (gender === "Anonymous" ? "Neutral" : gender) : "Select Gender"}
                {!genderLocked && (isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />)}
              </button>

              {isOpen && !genderLocked && (
                <div className="gender-menu">
                  <div className="gender-option" onClick={() => handleGenderSelect("Male")}>
                    Male
                  </div>
                  <div className="gender-option" onClick={() => handleGenderSelect("Female")}>
                    Female
                  </div>
                  <div className="gender-option" onClick={() => handleGenderSelect("Anonymous")}>
                    Prefer not to say
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="profile-box">
            <p className="label">User Information</p>
            <div className="info-details">
              <p>Name: <span className="info-value">{getProfileFullName()}</span></p>
              <p>Email: <span className="info-value">{getProfileEmail()}</span></p>
            </div>
          </div>

          <div className="profile-box about-box">
            <div className="box-header">
              <p className="label">About</p>
              <button className="edit-btn" onClick={() => setIsEditing(!isEditing)}>
                {isEditing ? "Save" : "Edit"}
              </button>
            </div>
            <div className="about-content-wrapper">
              {isEditing ? (
                <textarea
                  className="about-input"
                  value={about}
                  onChange={(e) => setAbout(e.target.value)}
                  placeholder="Write something about yourself..."
                />
              ) : (
                <p className="about-text">
                  {about || "No bio yet ＞︿＜"}
                </p>
              )}
            </div>
          </div>

          <div className="profile-box">
            <p className="label">Frequent Moods</p>
            <div className="tags">
              <span className="tag">Calm</span>
              <span className="tag">Thoughtful</span>
              <span className="tag">Tired</span>
              <span className="tag">Reflective</span>
            </div>
          </div>

          <div className="profile-box">
            <p className="label">Thoughts History</p>
            <div className="thoughts-list">
              <div className="thought-card">
                <p className="thought-date">2 days ago</p>
                <p className="thought-content">I felt calmer today after journaling.</p>
              </div>
              <div className="thought-card">
                <p className="thought-date">4 days ago</p>
                <p className="thought-content">My head was noisy but manageable.</p>
              </div>
              <div className="thought-card">
                <p className="thought-date">1 week ago</p>
                <p className="thought-content">A small win, but still a win.</p>
              </div>
            </div>
            <button
              className="see-all-btn"
              onClick={() => navigate("/profile/thoughts")}
            >
              See all →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Profile;