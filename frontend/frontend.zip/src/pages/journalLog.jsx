import React, { useState, useMemo } from "react";
import "../styles/journalLog.css";
import TopBar from "../components/topBar";
import { useNavigate } from "react-router-dom";

const entryColors = ["#b8c9ff", "#f3b8d9", "#d9b8e6", "#6bb397", "#c5e6d3"];

function assignColorsToEntries(entriesOfDay) {
  if (entriesOfDay.length === 1) {
    return [{ ...entriesOfDay[0], color: "#6bb397" }];
  }
  const pastel = entryColors.filter((c) => c !== "#6bb397");
  return entriesOfDay.map((e) => ({
    ...e,
    color: pastel[Math.floor(Math.random() * pastel.length)],
  }));
}

const journalData = [
  {
    id: 1,
    date: "2025-11-17",
    mood: "Calm",
    title: "Quiet morning",
    content:
      "I felt centered today. The air was quiet and soft. A slow start that felt good.",
  },
  {
    id: 2,
    date: "2025-11-17",
    mood: "Anxious",
    title: "Brain fog",
    content:
      "Hard time focusing but I tried. My mind was scattered but I kept pushing myself little by little. I was struggling but I didn’t give up.",
  },
  {
    id: 3,
    date: "2025-11-18",
    mood: "Happy",
    title: "Felt lighter today",
    content:
      "A little spark of energy. I don’t know why, but I woke up with a softer mind today.",
  },
];

function JournalLog() {
  const navigate = useNavigate();
  const [selectedDate, setSelectedDate] = useState(null);
  const [expandedEntry, setExpandedEntry] = useState(null);

  const today = new Date();
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());
  const [currentYear, setCurrentYear] = useState(today.getFullYear());

  const daysInMonth = useMemo(
    () => new Date(currentYear, currentMonth + 1, 0).getDate(),
    [currentMonth, currentYear]
  );

  const firstDayIndex = useMemo(
    () => new Date(currentYear, currentMonth, 1).getDay(),
    [currentMonth, currentYear]
  );

  const entriesByDay = useMemo(() => {
    const map = {};
    journalData.forEach((entry) => {
      const day = new Date(entry.date).getDate();
      if (!map[day]) map[day] = [];
      map[day].push(entry);
    });
    return map;
  }, []);

  const openDay = (day) => {
    setSelectedDate(day);
    setExpandedEntry(null);
  };

  const closeModal = () => {
    setSelectedDate(null);
    setExpandedEntry(null);
  };

  const renderSquares = (entries) => {
    const colored = assignColorsToEntries(entries);
    return (
      <div className="entry-squares">
        {colored.map((e) => (
          <div
            key={e.id}
            className="entry-square"
            style={{ backgroundColor: e.color }}
          ></div>
        ))}
      </div>
    );
  };

  const changeMonth = (offset) => {
    let newMonth = currentMonth + offset;
    let newYear = currentYear;
    if (newMonth < 0) {
      newMonth = 11;
      newYear--;
    }
    if (newMonth > 11) {
      newMonth = 0;
      newYear++;
    }
    setCurrentMonth(newMonth);
    setCurrentYear(newYear);
  };

  const weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  return (
    <div className="journal-log-page">
      <div className="journal-log-container">
        <button className="journal-back-btn" onClick={() => navigate("/journal")}>
          ←
        </button>

        <h1 className="journal-log-title">Journal Log</h1>

        <div className="month-selector">
          <button onClick={() => changeMonth(-1)}>←</button>
          <span>
            {new Date(currentYear, currentMonth).toLocaleString("default", {
              month: "long",
            })}{" "}
            {currentYear}
          </span>
          <button onClick={() => changeMonth(1)}>→</button>
        </div>

        <div className="calendar-wrapper">
          <div className="weekdays-row">
            {weekdays.map((w) => (
              <div className="weekday" key={w}>
                {w}
              </div>
            ))}
          </div>

          <div className="calendar-grid">
            {Array.from({ length: firstDayIndex }).map((_, i) => (
              <div className="empty-cell" key={"e" + i}></div>
            ))}

            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1;
              const entries = entriesByDay[day] || [];
              return (
                <div
                  key={day}
                  className="calendar-day"
                  onClick={() => openDay(day)}
                >
                  <span className="day-number">{day}</span>
                  {entries.length > 0 && renderSquares(entries)}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {selectedDate && (
        <div className="modal-overlay" onClick={closeModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>entries for {selectedDate}</h2>

            {entriesByDay[selectedDate]?.length ? (
              entriesByDay[selectedDate].map((entry) => (
                <div key={entry.id} className="modal-entry">
                  <h3>{entry.title}</h3>
                  <p className="modal-mood">{entry.mood}</p>
                  <p>
                    {expandedEntry === entry.id
                      ? entry.content
                      : entry.content.slice(0, 140) +
                        (entry.content.length > 140 ? "..." : "")}
                  </p>
                  {expandedEntry !== entry.id && (
                    <button
                      className="expand-btn"
                      onClick={() => setExpandedEntry(entry.id)}
                    >
                      read more →
                    </button>
                  )}
                </div>
              ))
            ) : (
              <p>no entries</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default JournalLog;
